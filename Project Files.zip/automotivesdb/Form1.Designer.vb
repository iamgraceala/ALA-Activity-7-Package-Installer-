﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ButtonLogout = New System.Windows.Forms.Button()
        Me.SupplierButton = New System.Windows.Forms.Button()
        Me.SoldButton = New System.Windows.Forms.Button()
        Me.CustomerButton = New System.Windows.Forms.Button()
        Me.StaffButton = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.Button1.Location = New System.Drawing.Point(67, 221)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(150, 130)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "List of For Sale Cars"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ButtonLogout
        '
        Me.ButtonLogout.Location = New System.Drawing.Point(249, 528)
        Me.ButtonLogout.Name = "ButtonLogout"
        Me.ButtonLogout.Size = New System.Drawing.Size(119, 34)
        Me.ButtonLogout.TabIndex = 7
        Me.ButtonLogout.Text = "LOGOUT"
        Me.ButtonLogout.UseVisualStyleBackColor = True
        '
        'SupplierButton
        '
        Me.SupplierButton.BackColor = System.Drawing.Color.Transparent
        Me.SupplierButton.BackgroundImage = CType(resources.GetObject("SupplierButton.BackgroundImage"), System.Drawing.Image)
        Me.SupplierButton.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Bold)
        Me.SupplierButton.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.SupplierButton.Location = New System.Drawing.Point(398, 221)
        Me.SupplierButton.Margin = New System.Windows.Forms.Padding(2)
        Me.SupplierButton.Name = "SupplierButton"
        Me.SupplierButton.Size = New System.Drawing.Size(150, 130)
        Me.SupplierButton.TabIndex = 8
        Me.SupplierButton.Text = "Supplier"
        Me.SupplierButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.SupplierButton.UseVisualStyleBackColor = False
        '
        'SoldButton
        '
        Me.SoldButton.BackColor = System.Drawing.Color.Transparent
        Me.SoldButton.BackgroundImage = CType(resources.GetObject("SoldButton.BackgroundImage"), System.Drawing.Image)
        Me.SoldButton.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Bold)
        Me.SoldButton.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.SoldButton.Location = New System.Drawing.Point(324, 375)
        Me.SoldButton.Margin = New System.Windows.Forms.Padding(2)
        Me.SoldButton.Name = "SoldButton"
        Me.SoldButton.Size = New System.Drawing.Size(150, 130)
        Me.SoldButton.TabIndex = 10
        Me.SoldButton.Text = "Sold Cars"
        Me.SoldButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.SoldButton.UseVisualStyleBackColor = False
        '
        'CustomerButton
        '
        Me.CustomerButton.BackColor = System.Drawing.Color.Transparent
        Me.CustomerButton.BackgroundImage = CType(resources.GetObject("CustomerButton.BackgroundImage"), System.Drawing.Image)
        Me.CustomerButton.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Bold)
        Me.CustomerButton.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.CustomerButton.Location = New System.Drawing.Point(148, 375)
        Me.CustomerButton.Margin = New System.Windows.Forms.Padding(2)
        Me.CustomerButton.Name = "CustomerButton"
        Me.CustomerButton.Size = New System.Drawing.Size(150, 130)
        Me.CustomerButton.TabIndex = 11
        Me.CustomerButton.Text = "Buyers"
        Me.CustomerButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CustomerButton.UseVisualStyleBackColor = False
        '
        'StaffButton
        '
        Me.StaffButton.BackColor = System.Drawing.Color.Transparent
        Me.StaffButton.BackgroundImage = CType(resources.GetObject("StaffButton.BackgroundImage"), System.Drawing.Image)
        Me.StaffButton.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Bold)
        Me.StaffButton.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.StaffButton.Location = New System.Drawing.Point(230, 221)
        Me.StaffButton.Margin = New System.Windows.Forms.Padding(2)
        Me.StaffButton.Name = "StaffButton"
        Me.StaffButton.Size = New System.Drawing.Size(150, 130)
        Me.StaffButton.TabIndex = 9
        Me.StaffButton.Text = "Staffs"
        Me.StaffButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.StaffButton.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(258, 230)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(93, 104)
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.Image = Global.StartHereDemo2.My.Resources.Resources.icons8_cars_90
        Me.PictureBox2.Location = New System.Drawing.Point(95, 233)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(93, 91)
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.Image = Global.StartHereDemo2.My.Resources.Resources.icons8_supplier_100
        Me.PictureBox3.Location = New System.Drawing.Point(416, 233)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(105, 97)
        Me.PictureBox3.TabIndex = 15
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.Image = Global.StartHereDemo2.My.Resources.Resources.icons8_cars_80
        Me.PictureBox4.Location = New System.Drawing.Point(354, 401)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(93, 80)
        Me.PictureBox4.TabIndex = 16
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.Image = Global.StartHereDemo2.My.Resources.Resources.icons8_buyer_90
        Me.PictureBox5.Location = New System.Drawing.Point(176, 389)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(93, 92)
        Me.PictureBox5.TabIndex = 17
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox6.Image = Global.StartHereDemo2.My.Resources.Resources.LOGO1
        Me.PictureBox6.Location = New System.Drawing.Point(63, 12)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(541, 602)
        Me.PictureBox6.TabIndex = 18
        Me.PictureBox6.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(616, 585)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CustomerButton)
        Me.Controls.Add(Me.SoldButton)
        Me.Controls.Add(Me.StaffButton)
        Me.Controls.Add(Me.SupplierButton)
        Me.Controls.Add(Me.ButtonLogout)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox6)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Form"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents ButtonLogout As Button
    Friend WithEvents SupplierButton As Button
    Friend WithEvents SoldButton As Button
    Friend WithEvents CustomerButton As Button
    Friend WithEvents StaffButton As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
End Class
