﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SoldCars
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SoldCars))
        Me.TextSaleDate = New System.Windows.Forms.TextBox()
        Me.LabelSaleDate = New System.Windows.Forms.Label()
        Me.TextSalePrice = New System.Windows.Forms.TextBox()
        Me.LabelSoldPrice = New System.Windows.Forms.Label()
        Me.DataGridViewSoldCars = New System.Windows.Forms.DataGridView()
        Me.DeleteSoldCars = New System.Windows.Forms.Button()
        Me.UpdateSoldCars = New System.Windows.Forms.Button()
        Me.TextSoldCustomerID = New System.Windows.Forms.TextBox()
        Me.LabelCustomerIDStaff = New System.Windows.Forms.Label()
        Me.TextSoldCarUnit = New System.Windows.Forms.TextBox()
        Me.TextSoldID = New System.Windows.Forms.TextBox()
        Me.LabellSoldCarUnit = New System.Windows.Forms.Label()
        Me.LabelSoldID = New System.Windows.Forms.Label()
        Me.btnAddSoldCars = New System.Windows.Forms.Button()
        Me.BackSoldCars = New System.Windows.Forms.Button()
        Me.LoginLabel = New System.Windows.Forms.Label()
        Me.PrintSoldCars = New System.Windows.Forms.Button()
        Me.saveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.CustomerButton1 = New System.Windows.Forms.Button()
        Me.StaffButton1 = New System.Windows.Forms.Button()
        Me.SupplierButton1 = New System.Windows.Forms.Button()
        Me.ForSaleButton1 = New System.Windows.Forms.Button()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.ReloadButton3 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DataGridViewSoldCars, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextSaleDate
        '
        Me.TextSaleDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSaleDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSaleDate.Location = New System.Drawing.Point(936, 326)
        Me.TextSaleDate.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSaleDate.Name = "TextSaleDate"
        Me.TextSaleDate.Size = New System.Drawing.Size(164, 24)
        Me.TextSaleDate.TabIndex = 60
        '
        'LabelSaleDate
        '
        Me.LabelSaleDate.AutoSize = True
        Me.LabelSaleDate.BackColor = System.Drawing.Color.Transparent
        Me.LabelSaleDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabelSaleDate.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSaleDate.Location = New System.Drawing.Point(816, 329)
        Me.LabelSaleDate.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSaleDate.Name = "LabelSaleDate"
        Me.LabelSaleDate.Size = New System.Drawing.Size(67, 18)
        Me.LabelSaleDate.TabIndex = 59
        Me.LabelSaleDate.Text = "Date Sold"
        '
        'TextSalePrice
        '
        Me.TextSalePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSalePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSalePrice.Location = New System.Drawing.Point(936, 287)
        Me.TextSalePrice.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSalePrice.Name = "TextSalePrice"
        Me.TextSalePrice.Size = New System.Drawing.Size(164, 24)
        Me.TextSalePrice.TabIndex = 58
        '
        'LabelSoldPrice
        '
        Me.LabelSoldPrice.AutoSize = True
        Me.LabelSoldPrice.BackColor = System.Drawing.Color.Transparent
        Me.LabelSoldPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabelSoldPrice.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSoldPrice.Location = New System.Drawing.Point(816, 293)
        Me.LabelSoldPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSoldPrice.Name = "LabelSoldPrice"
        Me.LabelSoldPrice.Size = New System.Drawing.Size(39, 18)
        Me.LabelSoldPrice.TabIndex = 57
        Me.LabelSoldPrice.Text = "Price"
        '
        'DataGridViewSoldCars
        '
        Me.DataGridViewSoldCars.BackgroundColor = System.Drawing.Color.White
        Me.DataGridViewSoldCars.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridViewSoldCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridViewSoldCars.GridColor = System.Drawing.Color.DarkOliveGreen
        Me.DataGridViewSoldCars.Location = New System.Drawing.Point(218, 173)
        Me.DataGridViewSoldCars.Name = "DataGridViewSoldCars"
        Me.DataGridViewSoldCars.Size = New System.Drawing.Size(555, 236)
        Me.DataGridViewSoldCars.TabIndex = 56
        '
        'DeleteSoldCars
        '
        Me.DeleteSoldCars.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.DeleteSoldCars.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.DeleteSoldCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteSoldCars.ForeColor = System.Drawing.Color.Snow
        Me.DeleteSoldCars.Location = New System.Drawing.Point(989, 396)
        Me.DeleteSoldCars.Margin = New System.Windows.Forms.Padding(2)
        Me.DeleteSoldCars.Name = "DeleteSoldCars"
        Me.DeleteSoldCars.Size = New System.Drawing.Size(111, 33)
        Me.DeleteSoldCars.TabIndex = 55
        Me.DeleteSoldCars.Text = "Delete Record"
        Me.DeleteSoldCars.UseVisualStyleBackColor = False
        '
        'UpdateSoldCars
        '
        Me.UpdateSoldCars.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.UpdateSoldCars.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.UpdateSoldCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateSoldCars.ForeColor = System.Drawing.Color.Snow
        Me.UpdateSoldCars.Location = New System.Drawing.Point(849, 441)
        Me.UpdateSoldCars.Margin = New System.Windows.Forms.Padding(2)
        Me.UpdateSoldCars.Name = "UpdateSoldCars"
        Me.UpdateSoldCars.Size = New System.Drawing.Size(111, 33)
        Me.UpdateSoldCars.TabIndex = 54
        Me.UpdateSoldCars.Text = "Update Record"
        Me.UpdateSoldCars.UseVisualStyleBackColor = False
        '
        'TextSoldCustomerID
        '
        Me.TextSoldCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSoldCustomerID.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSoldCustomerID.Location = New System.Drawing.Point(936, 243)
        Me.TextSoldCustomerID.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSoldCustomerID.Name = "TextSoldCustomerID"
        Me.TextSoldCustomerID.Size = New System.Drawing.Size(164, 24)
        Me.TextSoldCustomerID.TabIndex = 53
        '
        'LabelCustomerIDStaff
        '
        Me.LabelCustomerIDStaff.AutoSize = True
        Me.LabelCustomerIDStaff.BackColor = System.Drawing.Color.Transparent
        Me.LabelCustomerIDStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabelCustomerIDStaff.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCustomerIDStaff.Location = New System.Drawing.Point(816, 206)
        Me.LabelCustomerIDStaff.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelCustomerIDStaff.Name = "LabelCustomerIDStaff"
        Me.LabelCustomerIDStaff.Size = New System.Drawing.Size(84, 18)
        Me.LabelCustomerIDStaff.TabIndex = 52
        Me.LabelCustomerIDStaff.Text = "Customer ID"
        '
        'TextSoldCarUnit
        '
        Me.TextSoldCarUnit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSoldCarUnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSoldCarUnit.Location = New System.Drawing.Point(936, 200)
        Me.TextSoldCarUnit.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSoldCarUnit.Name = "TextSoldCarUnit"
        Me.TextSoldCarUnit.Size = New System.Drawing.Size(164, 24)
        Me.TextSoldCarUnit.TabIndex = 51
        '
        'TextSoldID
        '
        Me.TextSoldID.BackColor = System.Drawing.SystemColors.Window
        Me.TextSoldID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSoldID.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSoldID.Location = New System.Drawing.Point(936, 155)
        Me.TextSoldID.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSoldID.Name = "TextSoldID"
        Me.TextSoldID.Size = New System.Drawing.Size(164, 24)
        Me.TextSoldID.TabIndex = 50
        '
        'LabellSoldCarUnit
        '
        Me.LabellSoldCarUnit.AutoSize = True
        Me.LabellSoldCarUnit.BackColor = System.Drawing.Color.Transparent
        Me.LabellSoldCarUnit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabellSoldCarUnit.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabellSoldCarUnit.Location = New System.Drawing.Point(816, 252)
        Me.LabellSoldCarUnit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabellSoldCarUnit.Name = "LabellSoldCarUnit"
        Me.LabellSoldCarUnit.Size = New System.Drawing.Size(58, 18)
        Me.LabellSoldCarUnit.TabIndex = 49
        Me.LabellSoldCarUnit.Text = "Car Unit"
        '
        'LabelSoldID
        '
        Me.LabelSoldID.AutoSize = True
        Me.LabelSoldID.BackColor = System.Drawing.Color.Transparent
        Me.LabelSoldID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabelSoldID.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSoldID.Location = New System.Drawing.Point(816, 161)
        Me.LabelSoldID.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSoldID.Name = "LabelSoldID"
        Me.LabelSoldID.Size = New System.Drawing.Size(118, 18)
        Me.LabelSoldID.TabIndex = 48
        Me.LabelSoldID.Text = "Purchase Number"
        '
        'btnAddSoldCars
        '
        Me.btnAddSoldCars.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btnAddSoldCars.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddSoldCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSoldCars.ForeColor = System.Drawing.Color.Snow
        Me.btnAddSoldCars.Location = New System.Drawing.Point(849, 396)
        Me.btnAddSoldCars.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAddSoldCars.Name = "btnAddSoldCars"
        Me.btnAddSoldCars.Size = New System.Drawing.Size(111, 33)
        Me.btnAddSoldCars.TabIndex = 47
        Me.btnAddSoldCars.Text = "Add Record"
        Me.btnAddSoldCars.UseVisualStyleBackColor = False
        '
        'BackSoldCars
        '
        Me.BackSoldCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BackSoldCars.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.BackSoldCars.Location = New System.Drawing.Point(438, 446)
        Me.BackSoldCars.Name = "BackSoldCars"
        Me.BackSoldCars.Size = New System.Drawing.Size(112, 30)
        Me.BackSoldCars.TabIndex = 73
        Me.BackSoldCars.Text = "Back"
        Me.BackSoldCars.UseVisualStyleBackColor = True
        '
        'LoginLabel
        '
        Me.LoginLabel.AutoSize = True
        Me.LoginLabel.BackColor = System.Drawing.Color.Transparent
        Me.LoginLabel.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginLabel.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.LoginLabel.Location = New System.Drawing.Point(930, 97)
        Me.LoginLabel.Name = "LoginLabel"
        Me.LoginLabel.Size = New System.Drawing.Size(114, 36)
        Me.LoginLabel.TabIndex = 75
        Me.LoginLabel.Text = "FORM"
        '
        'PrintSoldCars
        '
        Me.PrintSoldCars.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.PrintSoldCars.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.PrintSoldCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrintSoldCars.ForeColor = System.Drawing.Color.Snow
        Me.PrintSoldCars.Location = New System.Drawing.Point(989, 443)
        Me.PrintSoldCars.Margin = New System.Windows.Forms.Padding(2)
        Me.PrintSoldCars.Name = "PrintSoldCars"
        Me.PrintSoldCars.Size = New System.Drawing.Size(111, 33)
        Me.PrintSoldCars.TabIndex = 76
        Me.PrintSoldCars.Text = "Print Record"
        Me.PrintSoldCars.UseVisualStyleBackColor = False
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.White
        Me.ListView1.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(808, -9)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(322, 594)
        Me.ListView1.TabIndex = 77
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'CustomerButton1
        '
        Me.CustomerButton1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CustomerButton1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerButton1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.CustomerButton1.Location = New System.Drawing.Point(20, 332)
        Me.CustomerButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.CustomerButton1.Name = "CustomerButton1"
        Me.CustomerButton1.Size = New System.Drawing.Size(179, 42)
        Me.CustomerButton1.TabIndex = 83
        Me.CustomerButton1.Text = "Buyers"
        Me.CustomerButton1.UseVisualStyleBackColor = False
        '
        'StaffButton1
        '
        Me.StaffButton1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.StaffButton1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StaffButton1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.StaffButton1.Location = New System.Drawing.Point(20, 276)
        Me.StaffButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.StaffButton1.Name = "StaffButton1"
        Me.StaffButton1.Size = New System.Drawing.Size(179, 42)
        Me.StaffButton1.TabIndex = 81
        Me.StaffButton1.Text = "Staffs"
        Me.StaffButton1.UseVisualStyleBackColor = False
        '
        'SupplierButton1
        '
        Me.SupplierButton1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.SupplierButton1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SupplierButton1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.SupplierButton1.Location = New System.Drawing.Point(20, 217)
        Me.SupplierButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.SupplierButton1.Name = "SupplierButton1"
        Me.SupplierButton1.Size = New System.Drawing.Size(179, 42)
        Me.SupplierButton1.TabIndex = 80
        Me.SupplierButton1.Text = "Supplier"
        Me.SupplierButton1.UseVisualStyleBackColor = False
        '
        'ForSaleButton1
        '
        Me.ForSaleButton1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ForSaleButton1.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForSaleButton1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ForSaleButton1.Location = New System.Drawing.Point(20, 161)
        Me.ForSaleButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.ForSaleButton1.Name = "ForSaleButton1"
        Me.ForSaleButton1.Size = New System.Drawing.Size(179, 42)
        Me.ForSaleButton1.TabIndex = 79
        Me.ForSaleButton1.Text = "List of For Sale Cars"
        Me.ForSaleButton1.UseVisualStyleBackColor = False
        '
        'ListView2
        '
        Me.ListView2.BackColor = System.Drawing.Color.White
        Me.ListView2.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(-10, -56)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(222, 641)
        Me.ListView2.TabIndex = 84
        Me.ListView2.UseCompatibleStateImageBehavior = False
        '
        'ReloadButton3
        '
        Me.ReloadButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReloadButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReloadButton3.Location = New System.Drawing.Point(556, 446)
        Me.ReloadButton3.Name = "ReloadButton3"
        Me.ReloadButton3.Size = New System.Drawing.Size(112, 30)
        Me.ReloadButton3.TabIndex = 85
        Me.ReloadButton3.Text = "Reload"
        Me.ReloadButton3.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.StartHereDemo2.My.Resources.Resources.LOGO1
        Me.PictureBox1.Location = New System.Drawing.Point(286, 7)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(487, 160)
        Me.PictureBox1.TabIndex = 86
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.Label1.Location = New System.Drawing.Point(52, 97)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 36)
        Me.Label1.TabIndex = 87
        Me.Label1.Text = "MENU"
        '
        'SoldCars
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1124, 531)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ReloadButton3)
        Me.Controls.Add(Me.CustomerButton1)
        Me.Controls.Add(Me.StaffButton1)
        Me.Controls.Add(Me.SupplierButton1)
        Me.Controls.Add(Me.ForSaleButton1)
        Me.Controls.Add(Me.LabelSaleDate)
        Me.Controls.Add(Me.LabelSoldPrice)
        Me.Controls.Add(Me.LabelCustomerIDStaff)
        Me.Controls.Add(Me.LabellSoldCarUnit)
        Me.Controls.Add(Me.LabelSoldID)
        Me.Controls.Add(Me.TextSaleDate)
        Me.Controls.Add(Me.TextSalePrice)
        Me.Controls.Add(Me.TextSoldCustomerID)
        Me.Controls.Add(Me.TextSoldCarUnit)
        Me.Controls.Add(Me.TextSoldID)
        Me.Controls.Add(Me.PrintSoldCars)
        Me.Controls.Add(Me.LoginLabel)
        Me.Controls.Add(Me.BackSoldCars)
        Me.Controls.Add(Me.DataGridViewSoldCars)
        Me.Controls.Add(Me.DeleteSoldCars)
        Me.Controls.Add(Me.UpdateSoldCars)
        Me.Controls.Add(Me.btnAddSoldCars)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.ListView2)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SoldCars"
        Me.Text = "SoldCars"
        CType(Me.DataGridViewSoldCars, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextSaleDate As TextBox
    Friend WithEvents LabelSaleDate As Label
    Friend WithEvents TextSalePrice As TextBox
    Friend WithEvents LabelSoldPrice As Label
    Friend WithEvents DataGridViewSoldCars As DataGridView
    Friend WithEvents DeleteSoldCars As Button
    Friend WithEvents UpdateSoldCars As Button
    Friend WithEvents TextSoldCustomerID As TextBox
    Friend WithEvents LabelCustomerIDStaff As Label
    Friend WithEvents TextSoldCarUnit As TextBox
    Friend WithEvents TextSoldID As TextBox
    Friend WithEvents LabellSoldCarUnit As Label
    Friend WithEvents LabelSoldID As Label
    Friend WithEvents btnAddSoldCars As Button
    Friend WithEvents BackSoldCars As Button
    Friend WithEvents LoginLabel As Label
    Friend WithEvents PrintSoldCars As Button
    Friend WithEvents saveFileDialog As SaveFileDialog
    Friend WithEvents ListView1 As ListView
    Friend WithEvents CustomerButton1 As Button
    Friend WithEvents StaffButton1 As Button
    Friend WithEvents SupplierButton1 As Button
    Friend WithEvents ForSaleButton1 As Button
    Friend WithEvents ListView2 As ListView
    Friend WithEvents ReloadButton3 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
End Class
