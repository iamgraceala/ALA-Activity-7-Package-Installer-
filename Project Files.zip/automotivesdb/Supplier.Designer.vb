﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Supplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Supplier))
        Me.TextSuppEmail = New System.Windows.Forms.TextBox()
        Me.LabelSuppEmail = New System.Windows.Forms.Label()
        Me.TextSuppAddress = New System.Windows.Forms.TextBox()
        Me.LabelSuppAddress = New System.Windows.Forms.Label()
        Me.DeleteSupplier = New System.Windows.Forms.Button()
        Me.UpdateSupplier = New System.Windows.Forms.Button()
        Me.TextSuppContact = New System.Windows.Forms.TextBox()
        Me.LabelSuppContact = New System.Windows.Forms.Label()
        Me.TextSuppName = New System.Windows.Forms.TextBox()
        Me.TextSuppID = New System.Windows.Forms.TextBox()
        Me.LabelSuppName = New System.Windows.Forms.Label()
        Me.LabelSupplierID = New System.Windows.Forms.Label()
        Me.btnAddSupplier = New System.Windows.Forms.Button()
        Me.BackSupplier = New System.Windows.Forms.Button()
        Me.LabelSupplier = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.dgreport = New System.Windows.Forms.DataGridView()
        Me.CustomerButton3 = New System.Windows.Forms.Button()
        Me.SoldButton3 = New System.Windows.Forms.Button()
        Me.StaffButton3 = New System.Windows.Forms.Button()
        Me.ForSaleButton3 = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ReloadButton2 = New System.Windows.Forms.Button()
        CType(Me.dgreport, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextSuppEmail
        '
        Me.TextSuppEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSuppEmail.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSuppEmail.Location = New System.Drawing.Point(904, 334)
        Me.TextSuppEmail.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSuppEmail.Name = "TextSuppEmail"
        Me.TextSuppEmail.Size = New System.Drawing.Size(184, 26)
        Me.TextSuppEmail.TabIndex = 60
        '
        'LabelSuppEmail
        '
        Me.LabelSuppEmail.AutoSize = True
        Me.LabelSuppEmail.BackColor = System.Drawing.Color.Transparent
        Me.LabelSuppEmail.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold)
        Me.LabelSuppEmail.Location = New System.Drawing.Point(804, 343)
        Me.LabelSuppEmail.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSuppEmail.Name = "LabelSuppEmail"
        Me.LabelSuppEmail.Size = New System.Drawing.Size(39, 17)
        Me.LabelSuppEmail.TabIndex = 59
        Me.LabelSuppEmail.Text = "Email"
        '
        'TextSuppAddress
        '
        Me.TextSuppAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSuppAddress.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSuppAddress.Location = New System.Drawing.Point(904, 291)
        Me.TextSuppAddress.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSuppAddress.Name = "TextSuppAddress"
        Me.TextSuppAddress.Size = New System.Drawing.Size(184, 26)
        Me.TextSuppAddress.TabIndex = 58
        '
        'LabelSuppAddress
        '
        Me.LabelSuppAddress.AutoSize = True
        Me.LabelSuppAddress.BackColor = System.Drawing.Color.Transparent
        Me.LabelSuppAddress.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold)
        Me.LabelSuppAddress.Location = New System.Drawing.Point(804, 296)
        Me.LabelSuppAddress.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSuppAddress.Name = "LabelSuppAddress"
        Me.LabelSuppAddress.Size = New System.Drawing.Size(56, 17)
        Me.LabelSuppAddress.TabIndex = 57
        Me.LabelSuppAddress.Text = "Address"
        '
        'DeleteSupplier
        '
        Me.DeleteSupplier.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.DeleteSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.DeleteSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteSupplier.ForeColor = System.Drawing.Color.Snow
        Me.DeleteSupplier.Location = New System.Drawing.Point(839, 467)
        Me.DeleteSupplier.Margin = New System.Windows.Forms.Padding(2)
        Me.DeleteSupplier.Name = "DeleteSupplier"
        Me.DeleteSupplier.Size = New System.Drawing.Size(112, 33)
        Me.DeleteSupplier.TabIndex = 55
        Me.DeleteSupplier.Text = "Delete Record"
        Me.DeleteSupplier.UseVisualStyleBackColor = False
        '
        'UpdateSupplier
        '
        Me.UpdateSupplier.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.UpdateSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.UpdateSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateSupplier.ForeColor = System.Drawing.Color.Snow
        Me.UpdateSupplier.Location = New System.Drawing.Point(976, 413)
        Me.UpdateSupplier.Margin = New System.Windows.Forms.Padding(2)
        Me.UpdateSupplier.Name = "UpdateSupplier"
        Me.UpdateSupplier.Size = New System.Drawing.Size(112, 33)
        Me.UpdateSupplier.TabIndex = 54
        Me.UpdateSupplier.Text = "Update Record"
        Me.UpdateSupplier.UseVisualStyleBackColor = False
        '
        'TextSuppContact
        '
        Me.TextSuppContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSuppContact.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSuppContact.Location = New System.Drawing.Point(904, 242)
        Me.TextSuppContact.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSuppContact.Name = "TextSuppContact"
        Me.TextSuppContact.Size = New System.Drawing.Size(184, 26)
        Me.TextSuppContact.TabIndex = 53
        '
        'LabelSuppContact
        '
        Me.LabelSuppContact.AutoSize = True
        Me.LabelSuppContact.BackColor = System.Drawing.Color.Transparent
        Me.LabelSuppContact.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSuppContact.Location = New System.Drawing.Point(804, 246)
        Me.LabelSuppContact.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSuppContact.Name = "LabelSuppContact"
        Me.LabelSuppContact.Size = New System.Drawing.Size(98, 15)
        Me.LabelSuppContact.TabIndex = 52
        Me.LabelSuppContact.Text = "Contact Number"
        '
        'TextSuppName
        '
        Me.TextSuppName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSuppName.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSuppName.Location = New System.Drawing.Point(904, 191)
        Me.TextSuppName.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSuppName.Name = "TextSuppName"
        Me.TextSuppName.Size = New System.Drawing.Size(184, 26)
        Me.TextSuppName.TabIndex = 51
        '
        'TextSuppID
        '
        Me.TextSuppID.BackColor = System.Drawing.SystemColors.Window
        Me.TextSuppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextSuppID.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextSuppID.Location = New System.Drawing.Point(904, 142)
        Me.TextSuppID.Margin = New System.Windows.Forms.Padding(2)
        Me.TextSuppID.Name = "TextSuppID"
        Me.TextSuppID.Size = New System.Drawing.Size(184, 26)
        Me.TextSuppID.TabIndex = 50
        '
        'LabelSuppName
        '
        Me.LabelSuppName.AutoSize = True
        Me.LabelSuppName.BackColor = System.Drawing.Color.Transparent
        Me.LabelSuppName.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSuppName.Location = New System.Drawing.Point(804, 195)
        Me.LabelSuppName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSuppName.Name = "LabelSuppName"
        Me.LabelSuppName.Size = New System.Drawing.Size(96, 15)
        Me.LabelSuppName.TabIndex = 49
        Me.LabelSuppName.Text = "Supplier's Name"
        '
        'LabelSupplierID
        '
        Me.LabelSupplierID.AutoSize = True
        Me.LabelSupplierID.BackColor = System.Drawing.Color.Transparent
        Me.LabelSupplierID.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold)
        Me.LabelSupplierID.Location = New System.Drawing.Point(804, 146)
        Me.LabelSupplierID.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelSupplierID.Name = "LabelSupplierID"
        Me.LabelSupplierID.Size = New System.Drawing.Size(73, 17)
        Me.LabelSupplierID.TabIndex = 48
        Me.LabelSupplierID.Text = "Supplier ID"
        '
        'btnAddSupplier
        '
        Me.btnAddSupplier.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btnAddSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSupplier.ForeColor = System.Drawing.Color.Snow
        Me.btnAddSupplier.Location = New System.Drawing.Point(839, 413)
        Me.btnAddSupplier.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAddSupplier.Name = "btnAddSupplier"
        Me.btnAddSupplier.Size = New System.Drawing.Size(112, 33)
        Me.btnAddSupplier.TabIndex = 47
        Me.btnAddSupplier.Text = "Add Record"
        Me.btnAddSupplier.UseVisualStyleBackColor = False
        '
        'BackSupplier
        '
        Me.BackSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BackSupplier.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.BackSupplier.Location = New System.Drawing.Point(419, 494)
        Me.BackSupplier.Name = "BackSupplier"
        Me.BackSupplier.Size = New System.Drawing.Size(98, 32)
        Me.BackSupplier.TabIndex = 73
        Me.BackSupplier.Text = "Back"
        Me.BackSupplier.UseVisualStyleBackColor = True
        '
        'LabelSupplier
        '
        Me.LabelSupplier.AutoSize = True
        Me.LabelSupplier.BackColor = System.Drawing.Color.Transparent
        Me.LabelSupplier.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSupplier.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.LabelSupplier.Location = New System.Drawing.Point(921, 72)
        Me.LabelSupplier.Name = "LabelSupplier"
        Me.LabelSupplier.Size = New System.Drawing.Size(114, 36)
        Me.LabelSupplier.TabIndex = 75
        Me.LabelSupplier.Text = "FORM"
        '
        'btnPrint
        '
        Me.btnPrint.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.Beige
        Me.btnPrint.Location = New System.Drawing.Point(976, 467)
        Me.btnPrint.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(112, 33)
        Me.btnPrint.TabIndex = 78
        Me.btnPrint.Text = "Print Record"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'dgreport
        '
        Me.dgreport.AllowUserToAddRows = False
        Me.dgreport.AllowUserToDeleteRows = False
        Me.dgreport.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.dgreport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgreport.Location = New System.Drawing.Point(248, 165)
        Me.dgreport.Margin = New System.Windows.Forms.Padding(2)
        Me.dgreport.Name = "dgreport"
        Me.dgreport.ReadOnly = True
        Me.dgreport.RowHeadersWidth = 51
        Me.dgreport.RowTemplate.Height = 24
        Me.dgreport.Size = New System.Drawing.Size(526, 281)
        Me.dgreport.TabIndex = 77
        '
        'CustomerButton3
        '
        Me.CustomerButton3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CustomerButton3.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.CustomerButton3.Location = New System.Drawing.Point(25, 378)
        Me.CustomerButton3.Margin = New System.Windows.Forms.Padding(2)
        Me.CustomerButton3.Name = "CustomerButton3"
        Me.CustomerButton3.Size = New System.Drawing.Size(191, 42)
        Me.CustomerButton3.TabIndex = 101
        Me.CustomerButton3.Text = "Buyers"
        Me.CustomerButton3.UseVisualStyleBackColor = False
        '
        'SoldButton3
        '
        Me.SoldButton3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.SoldButton3.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SoldButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.SoldButton3.Location = New System.Drawing.Point(25, 314)
        Me.SoldButton3.Margin = New System.Windows.Forms.Padding(2)
        Me.SoldButton3.Name = "SoldButton3"
        Me.SoldButton3.Size = New System.Drawing.Size(191, 46)
        Me.SoldButton3.TabIndex = 100
        Me.SoldButton3.Text = "Sold Cars"
        Me.SoldButton3.UseVisualStyleBackColor = False
        '
        'StaffButton3
        '
        Me.StaffButton3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.StaffButton3.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StaffButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.StaffButton3.Location = New System.Drawing.Point(25, 246)
        Me.StaffButton3.Margin = New System.Windows.Forms.Padding(2)
        Me.StaffButton3.Name = "StaffButton3"
        Me.StaffButton3.Size = New System.Drawing.Size(191, 42)
        Me.StaffButton3.TabIndex = 99
        Me.StaffButton3.Text = "Staffs"
        Me.StaffButton3.UseVisualStyleBackColor = False
        '
        'ForSaleButton3
        '
        Me.ForSaleButton3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ForSaleButton3.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForSaleButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ForSaleButton3.Location = New System.Drawing.Point(25, 182)
        Me.ForSaleButton3.Margin = New System.Windows.Forms.Padding(2)
        Me.ForSaleButton3.Name = "ForSaleButton3"
        Me.ForSaleButton3.Size = New System.Drawing.Size(191, 42)
        Me.ForSaleButton3.TabIndex = 97
        Me.ForSaleButton3.Text = "List of For Sale Cars"
        Me.ForSaleButton3.UseVisualStyleBackColor = False
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.White
        Me.ListView1.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(-5, -3)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(239, 594)
        Me.ListView1.TabIndex = 102
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'ListView2
        '
        Me.ListView2.BackColor = System.Drawing.Color.White
        Me.ListView2.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(799, -3)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(325, 594)
        Me.ListView2.TabIndex = 103
        Me.ListView2.UseCompatibleStateImageBehavior = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.Label1.Location = New System.Drawing.Point(51, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 36)
        Me.Label1.TabIndex = 104
        Me.Label1.Text = "MENU"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.StartHereDemo2.My.Resources.Resources.LOGO1
        Me.PictureBox1.Location = New System.Drawing.Point(274, -2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(500, 162)
        Me.PictureBox1.TabIndex = 105
        Me.PictureBox1.TabStop = False
        '
        'ReloadButton2
        '
        Me.ReloadButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReloadButton2.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReloadButton2.Location = New System.Drawing.Point(553, 494)
        Me.ReloadButton2.Name = "ReloadButton2"
        Me.ReloadButton2.Size = New System.Drawing.Size(98, 32)
        Me.ReloadButton2.TabIndex = 106
        Me.ReloadButton2.Text = "Reload"
        Me.ReloadButton2.UseVisualStyleBackColor = True
        '
        'Supplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.backgroundnew
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1124, 561)
        Me.Controls.Add(Me.ReloadButton2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CustomerButton3)
        Me.Controls.Add(Me.SoldButton3)
        Me.Controls.Add(Me.StaffButton3)
        Me.Controls.Add(Me.ForSaleButton3)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.dgreport)
        Me.Controls.Add(Me.LabelSupplier)
        Me.Controls.Add(Me.BackSupplier)
        Me.Controls.Add(Me.TextSuppEmail)
        Me.Controls.Add(Me.LabelSuppEmail)
        Me.Controls.Add(Me.TextSuppAddress)
        Me.Controls.Add(Me.LabelSuppAddress)
        Me.Controls.Add(Me.DeleteSupplier)
        Me.Controls.Add(Me.UpdateSupplier)
        Me.Controls.Add(Me.TextSuppContact)
        Me.Controls.Add(Me.LabelSuppContact)
        Me.Controls.Add(Me.TextSuppName)
        Me.Controls.Add(Me.TextSuppID)
        Me.Controls.Add(Me.LabelSuppName)
        Me.Controls.Add(Me.LabelSupplierID)
        Me.Controls.Add(Me.btnAddSupplier)
        Me.Controls.Add(Me.ListView2)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Supplier"
        Me.Text = "Supplier"
        CType(Me.dgreport, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextSuppEmail As TextBox
    Friend WithEvents LabelSuppEmail As Label
    Friend WithEvents TextSuppAddress As TextBox
    Friend WithEvents LabelSuppAddress As Label
    Friend WithEvents DeleteSupplier As Button
    Friend WithEvents UpdateSupplier As Button
    Friend WithEvents TextSuppContact As TextBox
    Friend WithEvents LabelSuppContact As Label
    Friend WithEvents TextSuppName As TextBox
    Friend WithEvents TextSuppID As TextBox
    Friend WithEvents LabelSuppName As Label
    Friend WithEvents LabelSupplierID As Label
    Friend WithEvents btnAddSupplier As Button
    Friend WithEvents BackSupplier As Button
    Friend WithEvents LabelSupplier As Label
    Friend WithEvents btnPrint As Button
    Friend WithEvents dgreport As DataGridView
    Friend WithEvents CustomerButton3 As Button
    Friend WithEvents SoldButton3 As Button
    Friend WithEvents StaffButton3 As Button
    Friend WithEvents ForSaleButton3 As Button
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ListView2 As ListView
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ReloadButton2 As Button
End Class
